export function track(_event: string, _payload?: Record<string, any>) {
  // Opcional: integrar GA4/Pixel aqui.
}
