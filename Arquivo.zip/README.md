# IMPULSE Site (Next.js + Tailwind)

## Rodar local
1) Instale dependências:
   npm install

2) Rode:
   npm run dev

## Ajustes rápidos
- Texto do site: `src/config/copy.ts`
- Cores/estilo: `src/app/globals.css`
- Webhook do lead: configure `LEAD_WEBHOOK_URL` em `.env.local`
